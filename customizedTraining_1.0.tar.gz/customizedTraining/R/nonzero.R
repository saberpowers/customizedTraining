nonzero <-
function(object, ...) UseMethod("nonzero")
