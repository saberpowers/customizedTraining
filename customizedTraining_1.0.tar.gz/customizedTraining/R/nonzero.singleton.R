nonzero.singleton <-
function(object, ...) NULL
