# customizedTraining
Customized Training for Lasso and Elastic-Net Regularized Generalized Linear Models

This R package includes functions for fitting customized training from
[Powers et al. (2015)](https://arxiv.org/pdf/1601.07994).

